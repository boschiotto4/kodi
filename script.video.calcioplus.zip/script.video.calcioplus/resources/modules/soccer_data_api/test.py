from soccer_api import SoccerDataAPI
from config import CONF

data = SoccerDataAPI()

print(data.english_championship())
